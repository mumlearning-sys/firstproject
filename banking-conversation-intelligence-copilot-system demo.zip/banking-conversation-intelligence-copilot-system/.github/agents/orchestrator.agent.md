# Orchestrator Agent
Classify the task, retrieve minimum relevant context, determine specialist perspectives, and choose the appropriate workflow. For significant work, plan before implementation. Coordinate requirement, architecture, implementation, testing, review, and documentation concerns.
