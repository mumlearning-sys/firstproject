# Repository-wide Copilot Instructions

## Project purpose
This repository contains an enterprise banking conversation intelligence application. The system processes customer and virtual-assistant conversation data and converts conversations into structured, traceable business insights.

Primary capabilities:
- conversation ingestion and normalization
- AI-powered conversation analysis
- customer problem identification
- sentiment analysis
- resolution and assistant accuracy assessment
- hierarchical taxonomy classification
- evidence extraction
- structured insight persistence
- analytics and conversation exploration
- AI evaluation and regression testing

## Architecture
Follow the repository's layered modular architecture.
- Presentation code must not contain core business logic.
- Streamlit pages call application services.
- Domain logic remains independent of UI frameworks, databases, and specific AI providers.
- Infrastructure integrations implement defined ports or abstractions.
- Place functionality according to responsibility, not convenience.

## AI rules
- Treat LLM output as untrusted until validated.
- Use structured outputs for business-critical processing.
- Validate outputs against defined schemas.
- Keep provider-specific logic in infrastructure.
- Capture provider, model, prompt version, timestamp, status, and failure information where applicable.
- Add evaluation cases for new AI capabilities.
- Do not send an entire taxonomy to an LLM by default when retrieval can narrow candidates.

## Data rules
- Do not load unnecessarily large datasets into application memory.
- Push filtering and aggregation to Snowflake where appropriate.
- Use pagination and controlled limits for exploration.
- Do not execute raw database queries directly from Streamlit pages.
- Use repository or data-access abstractions.
- Never hard-code credentials or secrets.

## Development behavior
For non-trivial changes:
1. Understand the requirement.
2. Retrieve minimum relevant project context.
3. Identify affected components.
4. Check architectural impact.
5. Create a plan.
6. Implement the smallest correct solution.
7. Add or update tests.
8. Review the change.
9. Update documentation where required.

Do not invent requirements. Record assumptions when needed. Do not make broad unrelated changes.

## Definition of done
A feature is complete only when applicable requirements are addressed, architecture is followed, tests are added and passing, errors are handled, logging is considered, security is reviewed, AI evaluation is added where relevant, and documentation is updated where needed.
