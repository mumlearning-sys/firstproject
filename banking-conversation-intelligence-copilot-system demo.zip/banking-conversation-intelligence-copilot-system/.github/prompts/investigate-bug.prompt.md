# Investigate Bug
Do not implement a speculative fix.
1. Reproduce or define reproduction conditions.
2. Inspect relevant code and tests.
3. Identify the most likely root cause.
4. Explain evidence.
5. Propose fix options.
6. Recommend a fix.
7. Add a regression test after the fix.
