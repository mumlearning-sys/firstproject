# Review Code
Review against:
- requirement compliance
- architecture
- code quality
- error handling
- testing
- security
- performance

Return required changes separately from optional improvements.
