# Plan Feature
Convert an approved requirement into an implementation plan.
Return:
- feature objective
- architecture impact
- affected modules
- implementation steps
- data changes
- AI changes
- test strategy
- risks
- definition of done

Inspect existing related code before recommending new abstractions.
