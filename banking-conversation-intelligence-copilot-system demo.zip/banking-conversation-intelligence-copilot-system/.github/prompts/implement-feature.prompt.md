# Implement Feature
Read the approved plan and relevant repository context.
- Inspect existing related code first.
- Reuse existing patterns where appropriate.
- Implement the smallest correct solution.
- Avoid unrelated refactors.
- Add or update tests.
- Report changed files and assumptions.
