# Architecture Change
Return:
- current architecture
- requested change
- why the current approach is insufficient
- options
- recommendation
- impact
- migration plan
- ADR requirement
- implementation plan
