# Generate Tests
Analyze the implementation and identify:
- normal cases
- edge cases
- failure cases
- integration requirements
- regression risks
- AI evaluation cases where applicable

Add tests appropriate to the architecture.
