# Analyze Requirement
Analyze the request before coding.
Return:
1. Understanding
2. Relevant context
3. Scope
4. Acceptance criteria
5. Dependencies
6. Assumptions
7. Risks
8. Recommended next step

Do not implement unless explicitly requested.
