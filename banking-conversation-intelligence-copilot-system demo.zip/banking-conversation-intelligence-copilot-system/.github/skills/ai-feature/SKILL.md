# AI Feature Skill
Workflow:
business requirement → input contract → prompt design → structured output → validation → error handling → traceability → evaluation.

Checklist:
- provider abstraction used
- prompt version defined
- input validated
- output schema defined
- output validated
- failure handling included
- retry behavior considered
- traceability captured
- evaluation cases added
