# Feature Development Skill
Workflow:
1. Read requirements.
2. Read relevant architecture.
3. Inspect existing code.
4. Plan.
5. Implement.
6. Test.
7. Review.
8. Update documentation.

Checklist:
- requirement understood
- relevant context loaded
- architecture checked
- dependencies identified
- plan available
- implementation completed
- tests added
- tests passed
- review completed
- documentation updated
