# Streamlit Development Skill
Flow:
user requirement → UI design → data requirement → application service → query/service → Snowflake → result → UI.

Rule: Streamlit is the presentation layer; it must not become the entire application.
