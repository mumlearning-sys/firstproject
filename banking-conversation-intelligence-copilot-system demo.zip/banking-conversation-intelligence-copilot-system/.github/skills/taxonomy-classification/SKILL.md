# Taxonomy Classification Skill
Preferred flow:
conversation → customer problem → problem summary → embedding/retrieval → top taxonomy candidates → LLM classification → hierarchical result → validation.

Rules:
- do not send the complete taxonomy by default
- retrieve candidates first
- preserve hierarchy
- support ambiguity
- support unknown/unclassified outcomes
- capture confidence carefully
- add ambiguous cases to evaluation data
