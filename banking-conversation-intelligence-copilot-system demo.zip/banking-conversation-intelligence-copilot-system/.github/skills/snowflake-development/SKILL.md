# Snowflake Development Skill
Checklist:
- repository abstraction used
- filtering pushed to source
- aggregation pushed to source where appropriate
- no unnecessary full-table load
- large result handling considered
- centralized connection reused
- credentials protected
- performance considered
