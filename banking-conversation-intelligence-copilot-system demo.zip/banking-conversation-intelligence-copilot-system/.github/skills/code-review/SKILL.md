# Code Review Skill
Review requirement + architecture + quality + testing + security + performance.

Checklist:
- solves requirement
- follows architecture
- responsibilities correctly placed
- external dependencies isolated
- errors handled
- tests sufficient
- secrets protected
- performance acceptable
- unnecessary changes avoided
