---
applyTo: "src/**/infrastructure/**/*.py,src/**/repositories/**/*.py"
---
# Snowflake Instructions
- Use repository or data-access abstractions.
- Do not put SQL in presentation code.
- Push filtering and aggregation to Snowflake where appropriate.
- Avoid unnecessary full-table loads.
- Use controlled limits and pagination.
- Reuse centralized connection configuration.
- Never hard-code credentials.
- Consider query efficiency.
