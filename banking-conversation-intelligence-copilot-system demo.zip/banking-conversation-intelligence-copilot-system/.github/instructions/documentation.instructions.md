---
applyTo: "docs/**/*.md,README.md"
---
# Documentation Instructions
Update documentation when behavior, architecture, configuration, interfaces, or workflows change.
Explain what changed, why it changed, how it is used, and important constraints.
Use ADRs for significant architecture decisions.
Avoid unnecessary duplication.
