---
applyTo: "tests/**/*.py"
---
# Testing Instructions
- Use pytest.
- Prefer Arrange, Act, Assert where practical.
- Isolate external dependencies in unit tests.
- Mock AI providers and database integrations in unit tests.
- Separate integration tests clearly.
- Test normal behavior, edge cases, and failures.
- Add regression tests for important defects.
- Add evaluation cases for AI functionality.
