---
applyTo: "src/**/ai/**/*.py,src/**/application/**/*.py,src/**/domain/**/*.py"
---
# AI Instructions
- Keep provider-specific calls out of domain logic.
- Use provider abstractions.
- Define structured output schemas.
- Validate business-critical responses.
- Handle malformed output, provider failures, and timeouts.
- Version prompts.
- Capture traceability metadata where required.
- Add evaluation cases.
