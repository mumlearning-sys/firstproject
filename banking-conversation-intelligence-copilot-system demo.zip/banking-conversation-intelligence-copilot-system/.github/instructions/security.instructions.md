---
applyTo: "**/*"
---
# Security Instructions
- Never hard-code secrets.
- Never commit credentials.
- Do not expose secrets in logs.
- Minimize sensitive conversation data in logs.
- Validate external input.
- Treat external responses as untrusted.
- Review authentication and authorization impacts for user-facing changes.
- Do not introduce insecure defaults.
