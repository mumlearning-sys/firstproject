---
applyTo: "src/**/*.py,tests/**/*.py,scripts/**/*.py"
---
# Python Instructions
- Use Python 3.11+.
- Use clear type hints for public interfaces.
- Prefer small focused functions and cohesive classes.
- Validate external input.
- Do not silently suppress exceptions.
- Avoid unnecessary global state.
- Keep domain logic independent of infrastructure.
- Design for testability.
