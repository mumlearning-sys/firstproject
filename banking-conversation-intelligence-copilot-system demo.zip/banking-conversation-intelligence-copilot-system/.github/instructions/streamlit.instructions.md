---
applyTo: "src/**/presentation/**/*.py"
---
# Streamlit Instructions
- Keep Streamlit focused on presentation and interaction.
- Do not place core business logic in pages.
- Do not execute raw database access from pages.
- Call application services.
- Use session state only for appropriate UI state.
- Cache deliberately.
- Avoid loading unnecessary large datasets.
- Create reusable components for repeated patterns.
