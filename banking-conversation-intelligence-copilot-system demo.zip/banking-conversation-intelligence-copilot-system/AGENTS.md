# ORC Development System

## Mission
Use an ORC-style workflow:
- O — Orchestrate: classify the task, identify context and specialist perspectives.
- R — Reason: analyze requirements, dependencies, assumptions, risks, and architecture.
- C — Coordinate: apply implementation, testing, security, AI, review, and documentation guidance.

## Task classification
Classify requests as one or more of:
- feature
- bug
- refactor
- AI feature
- taxonomy change
- architecture change
- UI change
- investigation

## Feature workflow
Understand → load relevant context → check requirements → check architecture → plan → implement → test → review → document.

## Bug workflow
Reproduce → investigate → identify root cause → plan fix → implement → add regression test → review.

## Architecture workflow
Document current state → impact analysis → options → recommendation → ADR where appropriate → implementation plan.

## Context principle
Use minimum relevant context. Prefer targeted requirements, architecture, domain documents, and related code over loading the entire repository.

## Completion
For significant work report:
1. understanding
2. context used
3. affected components
4. implementation plan or changes
5. tests
6. results
7. assumptions, risks, or follow-up
