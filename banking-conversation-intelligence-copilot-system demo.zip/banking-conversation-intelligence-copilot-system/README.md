# Banking Conversation Intelligence — Copilot Development System

This package provides the initial repository foundation for the enterprise banking conversation intelligence application and its ORC-style GitHub Copilot development system.

Included:
- Repository-wide Copilot instructions
- ORC orchestration instructions
- Path-specific instructions
- Reusable prompt workflows
- Specialist skills
- Agent templates
- Initial product, requirements, architecture, domain, and development context

## Recommended sequence
1. Extract into a new Git repository.
2. Review and adapt the project context.
3. Commit the development system.
4. Run the pilot validations in `docs/development/development-workflow.md`.
5. Begin application development from the epics.
