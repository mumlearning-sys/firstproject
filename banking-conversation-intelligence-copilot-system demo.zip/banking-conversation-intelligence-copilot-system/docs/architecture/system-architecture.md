# System Architecture

Source Conversations
→ Ingestion
→ Normalization
→ Application Services
→ AI Analysis
→ Taxonomy Classification
→ Insight Persistence
→ Analytics Services
→ Streamlit Presentation

External integrations such as Snowflake and AI providers belong behind infrastructure boundaries.
