# Data Architecture
Snowflake is the primary analytical persistence platform for conversation and insight data.

Principles:
- push filtering and aggregation to Snowflake
- avoid loading unnecessary large datasets into application memory
- use controlled result limits and pagination
- maintain traceability between source conversations and generated insights
