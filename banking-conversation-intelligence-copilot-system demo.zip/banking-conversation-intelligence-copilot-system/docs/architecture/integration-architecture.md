# Integration Architecture
AI: use provider abstractions; provider-specific code remains in infrastructure.
Embeddings: use an abstraction for retrieval and taxonomy candidate selection.
Snowflake: access through repositories or defined data-access abstractions.
Configuration: centralize configuration and keep secrets outside source control.
