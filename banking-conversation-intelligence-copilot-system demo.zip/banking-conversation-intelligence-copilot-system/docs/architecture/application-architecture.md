# Application Architecture

## Layers
### Presentation
Streamlit pages and reusable UI components.

### Application
Use cases, orchestration, services, and ports.

### Domain
Business models and business rules independent of frameworks.

### Infrastructure
Snowflake, AI providers, embeddings, repositories, configuration, and external integrations.

## Dependency direction
Presentation → Application → Domain.
Infrastructure implements or supports application boundaries.
Domain must not depend on Streamlit, Snowflake, or a specific LLM provider.
