# Taxonomy Domain Model
The taxonomy supports:
Level 1 → Level 2 → Level 3.

Preferred strategy:
1. derive a customer problem representation
2. retrieve relevant taxonomy candidates using semantic retrieval
3. select within the candidate set using an LLM or governed classifier
4. validate hierarchy
5. support ambiguous and unknown outcomes

Avoid sending hundreds of taxonomy options when retrieval can reduce context.
