# Conversation Domain Model
A conversation is a thread containing ordered messages and associated metadata.

Core concepts:
- Conversation
- Message
- Participant/Role
- Timestamp
- Conversation identifier
- Source metadata

The canonical model must not depend on source-specific JSON structures.
