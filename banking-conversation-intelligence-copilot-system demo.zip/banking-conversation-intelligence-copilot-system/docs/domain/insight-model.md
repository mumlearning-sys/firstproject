# Insight Domain Model
An insight represents structured analysis generated from a conversation.

Potential fields:
- customer problem summary
- sentiment
- resolution status
- assistant accuracy
- failure reason
- evidence
- confidence
- processing metadata

Business-critical AI output should be validated against structured schemas.
