# Business Requirements

## Business objective
Transform high-volume banking customer and virtual-assistant conversations into actionable structured insights.

## Functional requirements
- ingestion of conversation data
- normalization into a canonical conversation model
- thread-level analysis
- structured insight extraction
- sentiment and resolution assessment
- virtual-assistant accuracy assessment
- scalable three-level taxonomy classification
- storage of insights
- filtering, analytics, and exploration
- traceability of AI processing

## Non-functional requirements
- scalable architecture
- enterprise maintainability
- testability
- traceability
- controlled handling of sensitive data
- efficient use of Snowflake
- modular AI provider integration
