# Application Epics

## EPIC 1 — Project Foundation
Repository, configuration, architecture, models, quality tooling.

## EPIC 2 — Data Ingestion
Source contracts, adapters, validation, ingestion results.

## EPIC 3 — Conversation Normalization
Canonical conversation and message representation.

## EPIC 4 — AI Conversation Analysis
Problem identification, insight extraction, sentiment, resolution, and accuracy assessment.

## EPIC 5 — Taxonomy Classification
Retrieval-assisted hierarchical classification and ambiguity handling.

## EPIC 6 — Insight Persistence
Snowflake repositories and traceable insight storage.

## EPIC 7 — Analytics Services
Aggregations, filtering, KPI and analytical services.

## EPIC 8 — Streamlit Application
Business-facing exploration and analytics experience.

## EPIC 9 — AI Evaluation
Evaluation datasets, regression tests, quality measurement.

## EPIC 10 — Enterprise Quality and Operations
Security, observability, performance, resilience, and operational readiness.
