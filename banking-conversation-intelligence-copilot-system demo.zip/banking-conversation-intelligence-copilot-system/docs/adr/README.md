# Architecture Decision Records

Use ADRs for significant architectural decisions.

Format:
- Title
- Status
- Context
- Decision
- Consequences
- Alternatives considered
