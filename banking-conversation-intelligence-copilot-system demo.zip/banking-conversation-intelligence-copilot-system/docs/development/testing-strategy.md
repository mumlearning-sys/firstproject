# Testing Strategy
Use pytest.

Testing layers:
- unit tests for domain and application behavior
- integration tests for infrastructure boundaries
- regression tests for defects
- AI evaluation tests for AI capabilities

Cover normal, edge, and failure conditions.
