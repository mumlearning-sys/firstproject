# Development Workflow

## ORC workflow
Orchestrate → Reason → Coordinate.

For significant changes:
1. classify task
2. load minimum relevant context
3. analyze requirements
4. check architecture
5. create plan
6. implement
7. test
8. review
9. document

## Pilot validation tasks
### Pilot 1 — Domain
Create the Conversation domain model and validation.

### Pilot 2 — AI
Design a conversation insight extraction interface with structured output validation without integrating a real provider.

### Pilot 3 — Snowflake
Design the conversation repository interface and Snowflake implementation boundary.

The development system is validated when these pilots follow the intended architecture and include appropriate tests and review.
