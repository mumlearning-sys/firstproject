# Coding Standards
- prefer explicit, readable code
- use type hints for public interfaces
- keep responsibilities focused
- avoid hidden side effects
- validate external inputs
- handle errors explicitly
- isolate infrastructure dependencies
- do not perform unrelated refactors during feature work
