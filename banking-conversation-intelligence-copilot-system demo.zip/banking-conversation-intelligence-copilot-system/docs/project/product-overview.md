# Product Overview

## Product
An enterprise banking conversation intelligence platform that processes customer and virtual-assistant conversation data and transforms conversations into structured, searchable, traceable business insights.

## Primary capabilities
1. Conversation ingestion
2. Conversation normalization
3. AI-powered conversation analysis
4. Customer problem identification
5. Sentiment analysis
6. Resolution assessment
7. Assistant accuracy assessment
8. Hierarchical taxonomy classification
9. Evidence extraction
10. Structured insight persistence
11. Analytics and dashboards
12. Conversation exploration
13. AI evaluation and regression monitoring

## Design principles
- enterprise maintainability
- traceability
- provider independence
- scalable processing
- separation of concerns
- governed AI outputs
