# Banking Conversation Intelligence

Enterprise foundation for analyzing banking customer ↔ virtual-assistant conversations and producing structured, traceable insights.

## Included
- ORC-style GitHub Copilot development system
- Detailed requirements and epics
- Layered Python architecture
- Domain models
- Application ports and services
- AI provider abstraction and structured outputs
- Retrieval-assisted taxonomy classification design
- Snowflake repository boundaries and SQL templates
- Streamlit application foundation
- Configuration, logging, error handling
- Unit-test foundation
- AI evaluation framework
- Prompt templates and versioning structure

## Recommended build sequence
1. Install environment.
2. Run tests.
3. Configure secrets.
4. Validate the three Copilot pilot tasks.
5. Complete EPIC 1 foundation.
6. Build ingestion and normalization.
7. Add AI analysis.
8. Add taxonomy retrieval/classification.
9. Connect Snowflake.
10. Build analytics and Streamlit.
11. Run AI evaluation and enterprise hardening.

## Quick start
```bash
python -m venv .venv
# Activate the environment
pip install -e ".[dev]"
pytest
streamlit run src/banking_conversation_intelligence/presentation/app.py
```

Copy `.env.example` to `.env` and configure approved credentials before using real integrations.
