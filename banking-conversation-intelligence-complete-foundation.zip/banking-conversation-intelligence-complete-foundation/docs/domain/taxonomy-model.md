# Taxonomy Model

TaxonomyNode:
- taxonomy_id
- parent_id
- level
- name
- description
- active
- version

Classification:
- L1
- L2
- L3
- status
- confidence (optional, interpreted carefully)
- rationale/evidence where governed
