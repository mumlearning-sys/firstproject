# Conversation Model

Conversation:
- conversation_id
- messages
- source
- metadata

Message:
- message_id
- role
- content
- timestamp
- metadata

The model represents a canonical conversation independent of source format.
