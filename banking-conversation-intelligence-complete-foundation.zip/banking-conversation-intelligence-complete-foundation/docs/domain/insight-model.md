# Insight Model

ConversationInsight contains:
- conversation_id
- customer_problem_summary
- sentiment
- resolution_status
- assistant_accuracy
- failure_reason
- taxonomy classification
- evidence
- processing metadata

Exact business definitions must be finalized before production rollout.
