# Integration Architecture

AI provider, embedding provider, and Snowflake access must be isolated behind application-facing interfaces.

Secrets belong in approved environment/secret-management mechanisms and must never be committed.
