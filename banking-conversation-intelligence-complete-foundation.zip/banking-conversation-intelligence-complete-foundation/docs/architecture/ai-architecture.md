# AI Architecture

## Processing pipeline
Canonical Conversation
→ Input preparation
→ Versioned prompt
→ AI Provider Port
→ Structured output
→ Schema validation
→ Insight result
→ Processing metadata
→ Evaluation

## Provider boundary
Application code depends on an interface/port. OpenAI or another provider is implemented in infrastructure.

## Failure handling
Controlled handling for:
- provider errors
- timeouts
- malformed output
- schema validation failures

Do not silently convert AI failures into successful insights.
