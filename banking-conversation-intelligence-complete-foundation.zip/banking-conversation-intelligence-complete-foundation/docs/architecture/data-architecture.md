# Data Architecture

## Logical entities
- conversations
- messages
- conversation insights
- taxonomy nodes
- taxonomy versions
- AI processing runs
- evaluation cases
- evaluation results

## Principles
- source-to-insight traceability
- reprocessing support
- efficient analytics
- controlled large-result access
- filtering and aggregation pushdown
