# Snowflake Architecture

Suggested logical tables:
- RAW_CONVERSATIONS
- NORMALIZED_CONVERSATIONS
- CONVERSATION_INSIGHTS
- TAXONOMY
- AI_PROCESSING_AUDIT
- AI_EVALUATION_CASES
- AI_EVALUATION_RESULTS

Final physical design should be aligned to the actual enterprise Snowflake environment, governance, volumes, and access model.
