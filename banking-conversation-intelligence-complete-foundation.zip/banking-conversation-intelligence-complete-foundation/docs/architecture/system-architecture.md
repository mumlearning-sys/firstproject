# System Architecture

Source Conversations
→ Ingestion
→ Normalization
→ Application Services
→ AI Analysis
→ Taxonomy Classification
→ Insight Persistence
→ Analytics Services
→ Streamlit Presentation

Snowflake and AI providers are external infrastructure concerns behind defined interfaces.
