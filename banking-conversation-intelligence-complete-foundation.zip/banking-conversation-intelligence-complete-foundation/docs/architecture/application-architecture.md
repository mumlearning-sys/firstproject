# Application Architecture

## Layers
### Domain
Business models and rules.

### Application
Use cases, services, and ports.

### Infrastructure
AI providers, Snowflake repositories, embedding providers, and configuration adapters.

### Presentation
Streamlit pages and components.

## Dependency rule
Presentation → Application → Domain.
Infrastructure implements application ports.
Domain must not depend on Streamlit, Snowflake, or specific AI SDKs.
