# Taxonomy Architecture

## Problem
A large taxonomy should not be placed entirely into every classification prompt.

## Target approach
1. Create a customer problem representation.
2. Generate/query an embedding.
3. Retrieve relevant taxonomy candidates.
4. Apply hierarchy-aware classification.
5. Validate L1/L2/L3 relationships.
6. Support ambiguous or unknown results.
7. Store taxonomy and model/prompt metadata.

## Evaluation
Maintain representative and ambiguous examples. Measure candidate retrieval quality and final classification correctness separately.
