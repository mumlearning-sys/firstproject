# Architecture Decision Records

Use an ADR for significant decisions.

Template:
- Title
- Status
- Context
- Decision
- Consequences
- Alternatives considered
