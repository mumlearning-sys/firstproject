# Testing Strategy

## Unit tests
Domain and application behavior.

## Integration tests
AI provider and Snowflake adapters where environment access is available.

## Regression tests
Defects and previously observed failures.

## AI evaluation
Use fixed evaluation cases and expected structured outcomes where possible.
