# Coding Standards
Readable, explicit, typed public interfaces, focused responsibilities, validated external input, explicit errors, isolated integrations, minimal unrelated changes.
