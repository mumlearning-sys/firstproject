# Development Workflow

## Phase 1 — Validate Copilot system
Pilot 1: Conversation domain model.
Pilot 2: AI insight extraction interface.
Pilot 3: Snowflake repository boundary.

## Phase 2 — Build application
EPIC 01 → EPIC 10 in sequence, while allowing dependency-aware iteration.

## Standard significant change workflow
Requirement → Context → Architecture → Plan → Implement → Test → Review → Document.
