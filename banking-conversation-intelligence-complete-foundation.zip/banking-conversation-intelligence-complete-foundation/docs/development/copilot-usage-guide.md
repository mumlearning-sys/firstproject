# Copilot Usage Guide

## New feature
Use:
1. Analyze requirement
2. Plan feature
3. Review plan
4. Implement feature
5. Generate tests
6. Review code

## AI feature
Use the AI design prompt before implementation.

## Taxonomy feature
Use the taxonomy design prompt before implementation.

## Bug
Use investigate-bug and require evidence before applying a fix.
