# EPIC 02 — Data Ingestion

## Features
- source conversation contract
- ingestion port
- validation
- ingestion result model
- source adapters
- error reporting

## Acceptance criteria
Valid source conversations can be accepted, invalid records are reported explicitly, and source-specific formats do not leak into the canonical domain model.
