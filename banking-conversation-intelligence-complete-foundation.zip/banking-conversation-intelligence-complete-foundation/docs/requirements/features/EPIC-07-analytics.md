# EPIC 07 — Analytics Services

Provide application services for:
- KPIs
- trends
- taxonomy distribution
- sentiment distribution
- resolution analysis
- assistant accuracy analysis
- filtered conversation exploration

Large filtering and aggregation should be pushed to Snowflake where appropriate.
