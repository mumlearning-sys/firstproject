# EPIC 01 — Project Foundation

## Features
- package structure
- settings/configuration
- logging
- domain base models
- error conventions
- dependency boundaries
- pytest foundation
- application bootstrap

## Acceptance criteria
The repository installs, imports, runs tests, validates configuration, and provides clear boundaries for domain/application/infrastructure/presentation.
