# EPIC 04 — AI Conversation Analysis

## Features
- provider port
- prompt versioning
- structured output contract
- insight extraction service
- validation
- retry/failure strategy
- processing metadata
- mock provider for tests

## Acceptance criteria
A canonical conversation can be analyzed through an abstract provider and produces a validated ConversationInsight or an explicit controlled failure.
