# EPIC 09 — AI Evaluation

Requirements:
- evaluation dataset
- expected outputs
- evaluation runner
- regression comparison
- metrics
- failure review

Track at minimum structured validity and taxonomy correctness where labels exist.
