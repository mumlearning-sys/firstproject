# EPIC 03 — Conversation Normalization

Convert accepted source data into canonical Conversation and Message domain models.

Acceptance criteria:
- stable conversation identifier
- ordered messages
- normalized roles
- normalized timestamps where available
- source metadata preserved
- validation errors explicit
