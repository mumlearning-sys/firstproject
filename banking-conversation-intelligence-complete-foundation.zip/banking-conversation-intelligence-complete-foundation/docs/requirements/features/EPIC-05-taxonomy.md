# EPIC 05 — Taxonomy Classification

## Flow
Conversation → problem representation → embedding/retrieval → top candidates → classification → hierarchy validation → final classification.

## Requirements
- L1/L2/L3 hierarchy
- taxonomy version
- candidate retrieval abstraction
- ambiguity handling
- unknown outcome
- evaluation dataset
