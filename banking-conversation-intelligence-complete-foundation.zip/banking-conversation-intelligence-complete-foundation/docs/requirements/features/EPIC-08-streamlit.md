# EPIC 08 — Streamlit Application

## Initial screens
- executive overview
- conversation explorer
- taxonomy analysis
- issue/problem analysis
- quality/accuracy analysis

UI must call application services and not contain core business logic or direct raw SQL.
