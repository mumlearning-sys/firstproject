# Business Requirements

## Objective
Transform high-volume banking customer and virtual-assistant conversations into actionable structured insights.

## Functional requirements
### Conversation
- ingest source conversation data
- validate and normalize into a canonical model
- preserve source identifiers and message order

### AI analysis
- analyze full conversation context
- identify the underlying customer problem
- create concise problem summaries
- assess sentiment
- assess resolution
- assess assistant accuracy
- identify failure reasons where relevant
- return structured validated output

### Taxonomy
- support Level 1 → Level 2 → Level 3 hierarchy
- retrieve relevant candidates before classification
- support ambiguity and unknown/unclassified outcomes
- preserve taxonomy versioning

### Persistence and traceability
- persist normalized conversations and insights
- retain source-to-insight traceability
- retain AI processing metadata
- support reprocessing

### Analytics
- filter and aggregate large volumes efficiently
- explore conversations and insights
- surface KPI and trend analysis

## Non-functional requirements
Scalability, maintainability, testability, observability, security, controlled AI behavior, and Snowflake efficiency.
