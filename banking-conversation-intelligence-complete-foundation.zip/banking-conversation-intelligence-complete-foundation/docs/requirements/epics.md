# Application Epics

1. Project Foundation
2. Data Ingestion
3. Conversation Normalization
4. Domain and Insight Models
5. AI Conversation Analysis
6. Taxonomy Classification
7. Snowflake Persistence
8. Analytics Services
9. Streamlit Application
10. AI Evaluation
11. Enterprise Hardening and Operations
