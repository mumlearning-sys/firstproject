# ORC Development System

## O — Orchestrate
Classify the task and identify required context and specialist perspectives.

## R — Reason
Analyze requirements, dependencies, assumptions, risks, architecture, data, AI, testing, security, and performance.

## C — Coordinate
Apply the appropriate specialist guidance and workflow.

## Task types
feature, bug, refactor, AI feature, taxonomy change, architecture change, UI change, data change, investigation.

## Default significant-change workflow
Understand → Context → Requirements → Architecture → Plan → Implement → Test → Review → Document.

## Context principle
Use minimum relevant context. Prefer targeted documents and related code over loading the entire repository.

## Completion report
For significant work report:
- understanding
- context used
- affected components
- implementation
- tests
- results
- assumptions/risks/follow-up
