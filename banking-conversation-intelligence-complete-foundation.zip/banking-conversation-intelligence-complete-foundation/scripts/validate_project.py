from banking_conversation_intelligence.shared.config import Settings


if __name__ == "__main__":
    settings = Settings()
    print("Configuration loaded")
    print({"app_env": settings.app_env, "ai_provider": settings.ai_provider})
