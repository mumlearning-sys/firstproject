from banking_conversation_intelligence.application.services.analyze_conversation import AnalyzeConversationService
from banking_conversation_intelligence.domain.conversation import Conversation, Message, MessageRole
from banking_conversation_intelligence.infrastructure.ai.mock_provider import MockInsightExtractor


def test_analyze_conversation_returns_matching_id():
    service = AnalyzeConversationService(MockInsightExtractor())
    conversation = Conversation(
        conversation_id="c1",
        messages=[Message(role=MessageRole.CUSTOMER, content="I need help")],
    )
    insight = service.execute(conversation)
    assert insight.conversation_id == "c1"
