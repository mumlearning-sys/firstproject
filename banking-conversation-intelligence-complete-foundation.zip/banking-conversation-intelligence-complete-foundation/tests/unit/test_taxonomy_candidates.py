from banking_conversation_intelligence.application.services.classify_taxonomy import TaxonomyCandidateService
from banking_conversation_intelligence.domain.taxonomy import TaxonomyLevel, TaxonomyNode
from banking_conversation_intelligence.infrastructure.taxonomy.in_memory_retriever import InMemoryTaxonomyRetriever


def test_taxonomy_candidate_service_returns_candidates():
    nodes = [
        TaxonomyNode(
            taxonomy_id="1",
            level=TaxonomyLevel.LEVEL_1,
            name="Card",
            description="Card related issue",
        )
    ]
    service = TaxonomyCandidateService(InMemoryTaxonomyRetriever(nodes))
    assert service.get_candidates("card issue")
