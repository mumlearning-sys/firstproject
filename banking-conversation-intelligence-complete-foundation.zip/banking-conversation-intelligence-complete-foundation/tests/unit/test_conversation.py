from banking_conversation_intelligence.domain.conversation import Conversation, Message, MessageRole


def test_conversation_requires_messages():
    conversation = Conversation(
        conversation_id="c1",
        messages=[Message(role=MessageRole.CUSTOMER, content="Help me")],
    )
    assert conversation.conversation_id == "c1"
