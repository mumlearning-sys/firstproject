# Ai Feature Skill

Business objective → input contract → prompt → structured output → validation → failure handling → traceability → evaluation.
