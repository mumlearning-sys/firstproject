# Streamlit Development Skill

User requirement → UI → application service → data access → result → presentation. Keep business logic outside Streamlit.
