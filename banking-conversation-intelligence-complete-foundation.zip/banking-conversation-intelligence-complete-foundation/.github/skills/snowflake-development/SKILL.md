# Snowflake Development Skill

Repository boundary → efficient query → filtering/aggregation pushdown → controlled result size → centralized configuration → tests.
