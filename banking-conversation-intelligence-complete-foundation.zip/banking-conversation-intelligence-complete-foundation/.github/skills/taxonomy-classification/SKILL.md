# Taxonomy Classification Skill

Problem representation → embedding/retrieval → candidate set → hierarchical classification → validation → ambiguity/unknown handling → evaluation.
