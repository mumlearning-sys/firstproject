# Repository-wide Copilot Instructions

## Mission
Build an enterprise banking conversation intelligence platform. The system analyzes customer and virtual-assistant conversations and produces validated, traceable structured insights.

## Mandatory architecture
Presentation → Application → Domain.
Infrastructure implements ports and external integrations.
Domain code must not depend on Streamlit, Snowflake, or a specific AI provider.

## Working method
For significant changes:
1. Understand the request.
2. Load minimum relevant context.
3. Identify affected requirements and architecture.
4. Plan before coding.
5. Implement the smallest correct solution.
6. Add or update tests.
7. Review architecture, security, performance, and maintainability.
8. Update documentation when behavior or architecture changes.

## AI rules
- Treat AI output as untrusted until validated.
- Use structured schemas for business-critical outputs.
- Keep provider code in infrastructure.
- Version prompts.
- Capture processing metadata where appropriate.
- Add evaluation cases for new AI behavior.
- Prefer retrieval-assisted taxonomy classification over passing the complete taxonomy to the model.

## Data rules
- Do not load unnecessary large datasets into Streamlit or Python memory.
- Push filtering and aggregation to Snowflake where appropriate.
- Use repository boundaries.
- Never hard-code secrets.
- Minimize sensitive data in logs.

## Definition of done
Requirements satisfied, architecture respected, tests added, errors handled, security reviewed, performance considered, AI evaluation added where relevant, and documentation updated where required.
