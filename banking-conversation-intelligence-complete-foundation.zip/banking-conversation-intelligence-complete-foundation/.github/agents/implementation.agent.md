# Implementation Agent

Implement approved designs using existing patterns. Make focused changes and add tests.
