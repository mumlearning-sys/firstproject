# Analyze Requirement
Return understanding, relevant context, scope, acceptance criteria, dependencies, assumptions, risks, and recommended next step. Do not implement unless requested.
