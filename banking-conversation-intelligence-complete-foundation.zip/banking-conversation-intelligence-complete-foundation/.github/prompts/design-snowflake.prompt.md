# Design Snowflake Data Feature
Define logical model, physical tables, keys, clustering/performance considerations, repository interfaces, query patterns, pagination, retention, traceability, and security assumptions.
