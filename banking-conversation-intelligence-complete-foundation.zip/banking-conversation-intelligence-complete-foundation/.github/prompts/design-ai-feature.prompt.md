# Design AI Feature
Define business objective, input contract, prompt strategy, output schema, validation, failure handling, traceability, provider boundary, evaluation dataset, and acceptance criteria before implementation.
