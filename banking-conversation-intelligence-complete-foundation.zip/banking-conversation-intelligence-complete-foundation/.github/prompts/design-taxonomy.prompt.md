# Design Taxonomy Classification
Define hierarchy, canonical taxonomy schema, embedding text, retrieval strategy, candidate count, hierarchical constraints, ambiguity handling, unknown outcome, evaluation metrics, and storage requirements.
