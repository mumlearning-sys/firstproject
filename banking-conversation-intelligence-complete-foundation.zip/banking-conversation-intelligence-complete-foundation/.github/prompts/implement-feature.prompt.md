# Implement Feature
Read approved plan and relevant context. Reuse existing patterns. Implement the smallest correct change. Avoid unrelated refactors. Add tests and report changed files.
