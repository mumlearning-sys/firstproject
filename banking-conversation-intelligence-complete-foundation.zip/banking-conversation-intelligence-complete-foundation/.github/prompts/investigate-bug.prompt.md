# Investigate Bug
Reproduce → inspect → identify root cause with evidence → propose options → recommend fix → implement only after evidence → add regression test.
