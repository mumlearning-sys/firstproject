# Plan Feature
Inspect relevant requirements, architecture, and code. Return objective, affected modules, implementation steps, data changes, AI changes, test strategy, risks, and definition of done.
