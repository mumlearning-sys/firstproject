---
applyTo: "src/**/ai/**/*.py,src/**/application/**/*.py"
---
# AI
Use provider abstractions, versioned prompts, structured outputs, schema validation, explicit failure handling, and evaluation cases. Do not trust raw model output.
