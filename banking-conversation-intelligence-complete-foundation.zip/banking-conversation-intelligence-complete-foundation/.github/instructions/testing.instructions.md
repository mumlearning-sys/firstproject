---
applyTo: "tests/**/*.py"
---
# Testing
Use pytest. Cover normal, edge, and failure cases. Mock external AI and database boundaries in unit tests. Add regression tests for defects.
