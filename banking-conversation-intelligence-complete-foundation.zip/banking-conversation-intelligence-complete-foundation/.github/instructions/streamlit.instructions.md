---
applyTo: "src/**/presentation/**/*.py"
---
# Streamlit
Keep Streamlit as presentation. Call application services; do not embed business logic or raw database access in pages. Avoid loading unnecessary large datasets.
