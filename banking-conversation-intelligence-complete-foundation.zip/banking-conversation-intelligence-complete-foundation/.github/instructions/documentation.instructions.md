---
applyTo: "docs/**/*.md,README.md"
---
# Documentation
Update documentation when behavior, architecture, configuration, interfaces, or workflows change. Use ADRs for significant decisions.
