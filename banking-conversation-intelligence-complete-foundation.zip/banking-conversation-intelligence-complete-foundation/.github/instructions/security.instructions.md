---
applyTo: "**/*"
---
# Security
Never hard-code secrets. Do not log secrets or unnecessary sensitive conversation content. Validate external input and review authorization impacts.
