---
applyTo: "src/**/infrastructure/**/*.py"
---
# Snowflake
Use repository boundaries. Keep SQL out of presentation code. Push filtering and aggregation to Snowflake where appropriate. Avoid unnecessary full-table reads and hard-coded credentials.
