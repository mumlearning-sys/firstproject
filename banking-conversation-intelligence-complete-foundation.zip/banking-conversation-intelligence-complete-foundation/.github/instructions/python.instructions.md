---
applyTo: "src/**/*.py,tests/**/*.py"
---
# Python
Use Python 3.11+. Use type hints for public interfaces. Prefer focused functions, explicit errors, validated external input, and testable design. Keep domain independent from infrastructure.
