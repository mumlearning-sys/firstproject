import streamlit as st
from banking_conversation_intelligence.shared.config import Settings

settings = Settings()

st.set_page_config(page_title="Banking Conversation Intelligence", layout="wide")
st.title("Banking Conversation Intelligence")
st.caption("Enterprise conversation analytics foundation")

st.info(
    "Application foundation is running. Build analytics pages through application services, "
    "not direct database access."
)

with st.expander("Environment"):
    st.write({"app_env": settings.app_env, "ai_provider": settings.ai_provider})
