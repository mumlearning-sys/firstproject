from banking_conversation_intelligence.application.ports.taxonomy import TaxonomyRetrieverPort
from banking_conversation_intelligence.domain.taxonomy import TaxonomyNode


class InMemoryTaxonomyRetriever(TaxonomyRetrieverPort):
    def __init__(self, nodes: list[TaxonomyNode]):
        self._nodes = nodes

    def retrieve(self, query: str, limit: int = 10) -> list[TaxonomyNode]:
        query_lower = query.lower()
        ranked = sorted(
            self._nodes,
            key=lambda n: (query_lower in (n.name + " " + n.description).lower()),
            reverse=True,
        )
        return ranked[:limit]
