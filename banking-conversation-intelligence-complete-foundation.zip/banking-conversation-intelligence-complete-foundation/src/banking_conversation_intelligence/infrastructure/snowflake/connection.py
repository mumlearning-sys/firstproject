# Optional Snowflake integration.
# Install with: pip install -e ".[snowflake]"
#
# Centralize connection creation here and read credentials from Settings.
# Do not create Snowflake connections in Streamlit pages.
