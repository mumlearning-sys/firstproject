from banking_conversation_intelligence.application.ports.ai import InsightExtractorPort
from banking_conversation_intelligence.domain.conversation import Conversation
from banking_conversation_intelligence.domain.insight import (
    AssistantAccuracy,
    ConversationInsight,
    ProcessingMetadata,
    ResolutionStatus,
    Sentiment,
)


class MockInsightExtractor(InsightExtractorPort):
    def extract(self, conversation: Conversation) -> ConversationInsight:
        return ConversationInsight(
            conversation_id=conversation.conversation_id,
            customer_problem_summary="Mock analysis result",
            sentiment=Sentiment.UNKNOWN,
            resolution_status=ResolutionStatus.UNKNOWN,
            assistant_accuracy=AssistantAccuracy.UNKNOWN,
            processing=ProcessingMetadata(provider="mock", model="mock", prompt_version="v1"),
        )
