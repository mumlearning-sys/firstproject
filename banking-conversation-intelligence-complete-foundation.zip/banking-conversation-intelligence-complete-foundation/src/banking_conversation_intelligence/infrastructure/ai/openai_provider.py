# Optional provider implementation.
# Install with: pip install -e ".[ai]"
#
# Keep provider SDK code here, not in domain/application layers.
# Implement InsightExtractorPort and validate returned structured output
# against ConversationInsight before returning it to the application.
