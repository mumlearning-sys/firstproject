from abc import ABC, abstractmethod
from banking_conversation_intelligence.domain.conversation import Conversation
from banking_conversation_intelligence.domain.insight import ConversationInsight


class InsightExtractorPort(ABC):
    @abstractmethod
    def extract(self, conversation: Conversation) -> ConversationInsight:
        raise NotImplementedError
