from abc import ABC, abstractmethod
from banking_conversation_intelligence.domain.conversation import Conversation
from banking_conversation_intelligence.domain.insight import ConversationInsight


class ConversationRepositoryPort(ABC):
    @abstractmethod
    def get(self, conversation_id: str) -> Conversation | None:
        raise NotImplementedError


class InsightRepositoryPort(ABC):
    @abstractmethod
    def save(self, insight: ConversationInsight) -> None:
        raise NotImplementedError
