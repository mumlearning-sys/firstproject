from abc import ABC, abstractmethod
from banking_conversation_intelligence.domain.taxonomy import TaxonomyNode


class TaxonomyRetrieverPort(ABC):
    @abstractmethod
    def retrieve(self, query: str, limit: int = 10) -> list[TaxonomyNode]:
        raise NotImplementedError
