from banking_conversation_intelligence.application.ports.taxonomy import TaxonomyRetrieverPort
from banking_conversation_intelligence.domain.taxonomy import TaxonomyNode


class TaxonomyCandidateService:
    def __init__(self, retriever: TaxonomyRetrieverPort):
        self._retriever = retriever

    def get_candidates(self, customer_problem: str, limit: int = 10) -> list[TaxonomyNode]:
        if not customer_problem.strip():
            raise ValueError("customer_problem must not be empty")
        return self._retriever.retrieve(customer_problem, limit=limit)
