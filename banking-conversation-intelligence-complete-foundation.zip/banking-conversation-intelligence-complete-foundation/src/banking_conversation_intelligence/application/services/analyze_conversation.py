from banking_conversation_intelligence.application.ports.ai import InsightExtractorPort
from banking_conversation_intelligence.application.ports.repositories import InsightRepositoryPort
from banking_conversation_intelligence.domain.conversation import Conversation
from banking_conversation_intelligence.domain.insight import ConversationInsight


class AnalyzeConversationService:
    def __init__(self, extractor: InsightExtractorPort, insight_repository: InsightRepositoryPort | None = None):
        self._extractor = extractor
        self._insight_repository = insight_repository

    def execute(self, conversation: Conversation) -> ConversationInsight:
        insight = self._extractor.extract(conversation)
        if insight.conversation_id != conversation.conversation_id:
            raise ValueError("Insight conversation_id does not match input conversation.")
        if self._insight_repository:
            self._insight_repository.save(insight)
        return insight
