from enum import IntEnum
from pydantic import BaseModel, Field


class TaxonomyLevel(IntEnum):
    LEVEL_1 = 1
    LEVEL_2 = 2
    LEVEL_3 = 3


class TaxonomyNode(BaseModel):
    taxonomy_id: str = Field(min_length=1)
    parent_id: str | None = None
    level: TaxonomyLevel
    name: str = Field(min_length=1)
    description: str = ""
    active: bool = True
    version: str = "1"
