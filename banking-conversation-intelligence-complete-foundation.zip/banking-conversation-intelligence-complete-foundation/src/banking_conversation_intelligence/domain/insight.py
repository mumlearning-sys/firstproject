from enum import StrEnum
from typing import Any
from pydantic import BaseModel, Field


class Sentiment(StrEnum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"
    MIXED = "mixed"
    UNKNOWN = "unknown"


class ResolutionStatus(StrEnum):
    RESOLVED = "resolved"
    PARTIALLY_RESOLVED = "partially_resolved"
    NOT_RESOLVED = "not_resolved"
    UNKNOWN = "unknown"


class AssistantAccuracy(StrEnum):
    ACCURATE = "accurate"
    PARTIALLY_ACCURATE = "partially_accurate"
    INACCURATE = "inaccurate"
    NOT_APPLICABLE = "not_applicable"
    UNKNOWN = "unknown"


class Evidence(BaseModel):
    message_id: str | None = None
    text: str = Field(min_length=1)


class TaxonomyClassification(BaseModel):
    level_1: str | None = None
    level_2: str | None = None
    level_3: str | None = None
    status: str = "unclassified"
    confidence: float | None = Field(default=None, ge=0, le=1)


class ProcessingMetadata(BaseModel):
    provider: str | None = None
    model: str | None = None
    prompt_version: str | None = None
    raw_metadata: dict[str, Any] = Field(default_factory=dict)


class ConversationInsight(BaseModel):
    conversation_id: str
    customer_problem_summary: str
    sentiment: Sentiment = Sentiment.UNKNOWN
    resolution_status: ResolutionStatus = ResolutionStatus.UNKNOWN
    assistant_accuracy: AssistantAccuracy = AssistantAccuracy.UNKNOWN
    failure_reason: str | None = None
    taxonomy: TaxonomyClassification = Field(default_factory=TaxonomyClassification)
    evidence: list[Evidence] = Field(default_factory=list)
    processing: ProcessingMetadata = Field(default_factory=ProcessingMetadata)
