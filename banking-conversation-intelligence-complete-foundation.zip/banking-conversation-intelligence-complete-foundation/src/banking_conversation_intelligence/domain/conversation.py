from datetime import datetime
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, Field, model_validator


class MessageRole(StrEnum):
    CUSTOMER = "customer"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    OTHER = "other"


class Message(BaseModel):
    message_id: str | None = None
    role: MessageRole
    content: str = Field(min_length=1)
    timestamp: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Conversation(BaseModel):
    conversation_id: str = Field(min_length=1)
    messages: list[Message] = Field(min_length=1)
    source: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_message_order(self) -> "Conversation":
        timestamps = [m.timestamp for m in self.messages if m.timestamp is not None]
        if timestamps and timestamps != sorted(timestamps):
            raise ValueError("Messages with timestamps must be ordered chronologically.")
        return self
