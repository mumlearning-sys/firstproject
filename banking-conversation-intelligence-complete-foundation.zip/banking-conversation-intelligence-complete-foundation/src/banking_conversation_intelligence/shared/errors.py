class ApplicationError(Exception):
    """Base controlled application error."""


class ValidationError(ApplicationError):
    """Raised when external or domain input is invalid."""


class IntegrationError(ApplicationError):
    """Raised when an external integration fails."""


class AIProcessingError(ApplicationError):
    """Raised when AI processing cannot produce a valid result."""
