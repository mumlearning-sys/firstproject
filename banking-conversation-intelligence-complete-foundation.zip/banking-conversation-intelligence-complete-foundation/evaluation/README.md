# AI Evaluation

Store representative evaluation cases outside production code.

Recommended fields:
- case_id
- conversation fixture/reference
- expected problem summary criteria
- expected sentiment
- expected resolution
- expected accuracy
- expected taxonomy
- notes

Run evaluations when prompts, models, taxonomy, or AI orchestration changes.
